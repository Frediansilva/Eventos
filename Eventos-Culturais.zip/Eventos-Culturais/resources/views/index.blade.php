<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de clientes</title>
</head>
<body>

<table>
    <tr>
        <th>Nome</th>
        <th>telefone</th>
        <th>Email</th>
        <th>Endereço</th>

    </tr>

</table>
    
</body>
</html>