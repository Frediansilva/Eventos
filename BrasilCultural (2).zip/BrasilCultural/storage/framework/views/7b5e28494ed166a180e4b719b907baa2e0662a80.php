<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <title>Cadastrar Pacientes</title>
</head>
<body >
    <form action="<?php echo e(route('Pacientes.store')); ?>" method="post" align="center" border="1">
            <?php echo csrf_field(); ?>
            <p>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome">
            </p>
            <p>
                <label for="endereco">Endereço:</label>
                <input type="text" name="endereco" id="endereco">
            </p>
            <p>
                <label for="cpf">CPF:</label>
                <input type="number" name="cpf" id="cpf">
        </p>
        <p>
            <label for="sexo">Sexo:</label>
            <input type="text" name="sexo" id="sexo">
        </p>
        <p>
            <label for="escolaridade">Escolaridade:</label>
            <input type="text" name="escolaridade" id="escolaridade">
        </p>
        <p>
            <label for="email">Email:</label>
            <input type="text" name="email" id="email">
        </p>
        <p>
            <label for="nascimento">Nascimento:</label>
            <input type="text" name="nascimento" id="nascimento">
        </p>
        <p>
            <label for="telefone">Telefone:</label>
            <input type="text" name="telefone" id="telefone">
        </p>
        <p>
            <label for="user_id">Usuario:</label>
            <input type="number" name="user_id" id="user_id">
        </p>
        <input type="submit" value="Cadastrar">
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH E:\www\tads\resources\views/Pacientes/create.blade.php ENDPATH**/ ?>