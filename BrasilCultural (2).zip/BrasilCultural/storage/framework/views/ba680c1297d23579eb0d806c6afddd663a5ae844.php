  

  <?php $__env->startSection('title','Criar Post'); ?>

  <?php $__env->startSection('content'); ?>    
  <form action="<?php echo e(route('posts.store')); ?>?armazena=true" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Título:</label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title')); ?>">
        </div>
        <div class="form-group">
            <label for="description">Descrição:</label>
            <input type="text" name="description" id="description" class="form-control" value="<?php echo e(old('description')); ?>">
        </div>
        <div class="form-group">
            <label for="content">Conteúdo:</label>
            <textarea name="content" id="content" cols="30" rows="10"><?php echo e(old('content')); ?></textarea>
        </div>
        <div class="form-group">
            <label for="slug">Slug:</label>
            <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e(old('slug')); ?>">
        </div>
        
        <div class="form-group">
            <label for="user">User:</label>
            <select name="user" id="user">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <button class="btn btn-lg btn-success">Criar Postagem</button>
    </form>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tads\resources\views/posts/create.blade.php ENDPATH**/ ?>