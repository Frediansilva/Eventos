

<?php $__env->startSection('title','Exibir Post: '.$post->title); ?>

<?php $__env->startSection('content'); ?>  
    <p>
        Title: <?php echo e($post->title); ?>

    </p>
    <p>
        Description: <?php echo e($post->description); ?>

    </p>
    <p>
        Content: <?php echo e($post->content); ?>

    </p>
    <p>
        Slug: <?php echo e($post->slug); ?>

    </p>
    <p>
        User id: <?php echo e($post->user_id); ?>

    </p>
    <p>
        Is active: <?php echo e($post->is_active); ?>

    </p>

    <form action="<?php echo e(route('posts.index')); ?>" method="get">
    <input type="submit" value="Back"></form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tads\resources\views/posts/show.blade.php ENDPATH**/ ?>