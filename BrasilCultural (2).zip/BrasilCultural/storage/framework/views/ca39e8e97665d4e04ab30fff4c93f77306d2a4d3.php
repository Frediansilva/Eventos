<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pacientes</title>
</head>
<body>
    <table>
        <tr>
            <th>Nome</th>
            <th>CPF</th>
            <th>Usuario</th>
            <th>Alterar</th>
            <th>Excluir</th>
        </tr>
        <?php
            foreach ($Pacientes as $paciente) :
        ?>
        <tr>
            <td><?php echo e($paciente->nome); ?></td>
            <td><?php echo e($paciente->cpf); ?></td>
            <td><?php echo e($paciente->user_id); ?></td>
            <td>
                <form action="<?php echo e(route('Pacientes.edit',['paciente' => $paciente->id])); ?>" method="get">
                    <input type="submit" value="Alterar">
                </form>
            </td>
            <td>
                <form action="<?php echo e(route('Pacientes.destroy',['paciente' => $paciente->id])); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Excluir">
                </form>
            </td>
        </tr>
        <?php 
            endforeach;
        ?>
    </table>
    
</body>
</html><?php /**PATH D:\www\tads\resources\views/Pacientes/index.blade.php ENDPATH**/ ?>