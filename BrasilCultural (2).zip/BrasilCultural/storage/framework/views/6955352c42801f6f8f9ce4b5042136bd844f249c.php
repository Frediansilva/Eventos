

<?php $__env->startSection('title',"Postagens do usuário $user->name"); ?>;

<?php $__env->startSection('content'); ?>  
    <table border="1">
        <tr>
            <th>Title</th>
            <th>Show</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($post->title); ?></td>
                <td>
                    <form action="<?php echo e(route('posts.show',['post' => $post->id])); ?>" method="get">
                        <input type="submit" value="Show">
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route('posts.edit',['post' => $post->id])); ?>" method="get">
                        <input type="submit" value="Edit">
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route('posts.destroy',['post' => $post->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                        <input type="submit" value="Delete">
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4"> Nenhum registro </td>
            </tr>              
            <?php endif; ?>
    </table>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\BrasilCultural\resources\views/users/posts.blade.php ENDPATH**/ ?>