

<?php $__env->startSection('title','Editar Post'); ?>

<?php $__env->startSection('content'); ?>  
    <form action="<?php echo e(route('posts.update',['post' => $post->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Título:</label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo e($post->title); ?>">
        </div>
        <div class="form-group">
            <label for="description">Descrição:</label>
            <input type="text" name="description" id="description" class="form-control" value="<?php echo e($post->description); ?>">
        </div>
        <div class="form-group">
            <label for="content">Conteúdo:</label>
            <textarea name="content" id="content" cols="30" rows="10"><?php echo e($post->content); ?></textarea>
        </div>
        <div class="form-group">
            <label for="slug">Slug:</label>
            <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e($post->slug); ?>">
        </div>

        <button class="btn btn-lg btn-success">Atualizar Postagem</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tads\resources\views/posts/edit.blade.php ENDPATH**/ ?>