<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


use App\Models\Post;
use App\Models\User;
use Illuminate\Http\Request;



class RecadoController extends Controller
{


    public function index()
    {
        $posts = Post::all();
        return view('recados.index',compact('recados'));
    }

    public function show(Post $post)
    {
        return view('recados.show',compact('recados'));
    }


    public function create()
    {
     return view('recados.create');
    }

    public function store(Request $request)
    {
        if (empty($request->nome) || empty($request->cidade) || empty($request->email) || empty($request->recado)){
            return back()->withInput();
        }else{
            dd($request->all());
        }
    }
}
