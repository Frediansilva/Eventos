<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;

class UsuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Pacientes = Usuario::all();
        return view('Pacientes.index',compact('Pacientes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Pacientes.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Usuario::create($request->all());

        return redirect()->route('Pacientes.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Usuario  $Usuario
     * @return \Illuminate\Http\Response
     */
    public function show(Usuario $Usuario)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Usuario  $Usuario
     * @return \Illuminate\Http\Response
     */
    public function edit(Usuario $Usuario)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Usuario  $Usuario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Usuario $Usuario)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Usuario  $Usuario
     * @return \Illuminate\Http\Response
     */
    public function destroy(Usuario $Usuario)
    {
        //
    }
}
