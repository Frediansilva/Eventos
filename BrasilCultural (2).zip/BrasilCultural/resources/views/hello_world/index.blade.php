<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Página Administrativa">
    <meta name="author" content="Cesar">
    <link rel="icon" href="imagens/favicon.ico">

    @extends('layouts.app')
   
    <title>Brasil Cultural</title>
</head>
<body>

   
    <p>Bem vindo(a) {{$nome}}!</p>

    <div class="container theme-showcase" role="main">      
      <div class="page-header">
      <br><br>
         <img src="{{ asset('img/eventos1.jpg') }}" /><br><br><br>

         <div class="card user-activity">
             <a href="http://localhost:8000/eventos.blade.php" class="btn">Eventos</a>
             <a href="http://localhost:8000/index.php/admin/posts/create" class="btn btn-lg btn-success">Cadastrar</a>
             
         </div>
        <h1  align="center">Bem vindo ao Brasil Cultural</h1>
        <h2  align="center">Conheça nosso calendário de eventes pelo Brasil</h2>
      </div>
      <div
    </div> <!-- /container -->
 
    <!-- Statistics Section-->
    <section class="statistics">
        <div class="container-fluid">
            <div class="row d-flex">
                <div class="col-lg-6">
                    <!-- Income-->
                    <div class="card income text-center">
                        <div class="icon"><i class="icon-line-chart"></i></div>
                        
                       <br>
                        <h4>Mostra de Dança abre a programação</h4>
                        <p align="justify">Este fim de semana, até o domingo (2), a 7ª Mostra de Dança abre a programação com apresentações de samba, flamenco, danças folclóricas e contemporânea. O evento será a partir das 20h na Praça Cine Teatro e segue até domingo.

        O dia 7 de julho abre a programação de dois eventos, a Exposição de Artes Plásticas e Fotografia Arte no Cit 6, e o 16º Extremamente Caipira, que tem apresentações de intérpretes da música caipira e quadrilha.
        No fim de semana do dia 14 e 15 de julho, o blues e o jazz tomam conta da cidade com um festival de apresentações. De 16 a 26 de julho, o Festival de Teatro começa na cidade, seguido da 8ª Feira Holística que acontece no fim de semana dos dias 22 e 23 de julho.</p>
        
        <strong class="text-primary">Mostra de Dança</strong>
        <br> <br> <br>
        <img src="{{ asset('img/eventos2.jpg') }}" />
                    </div>
                </div>
                <div class="col-lg-6">
                   
                    <!-- User Actibity-->
                    
                    <div class="card user-activity">
                        <img src="{{ asset('img/eventos3.jpg') }}" /><br>
                        <h2 class="display h4">User Activity</h2>
                        <footer>
       
            </footer>
                        <p display" align="justify">
Sexta-feira 07/07:

18h – Quadrilha Primeiros Passos

22 h – DuplaRoberto & Alessandro

23h30 – Fechamento DJ<br><br><br>

Sábado 08/07:

12h - Abertura e Dj

12h30 – Gean Luca & Diego

13h30 – Gustavo Viola e Willian

15h - Grupo de Viola e Catira Terra Batida

16h - Rodrigo Nalli& Rafael

17h - Quadrilha e Grupo de Seresta Renascer

21h – Quadrilha Proficional “Tia Chalico”

22h30 - As Irmãs Galvão<br><br><br>

Domingo 09/07:

12h – Cortejo do Divino

12h30 – Canto da Terra - Divineiros de Joanópolis - Violeiros do Divino de Bragança Paulista

13h - Caixeiras da Serra de Extrema

13h30 - Orquestra de Violeiros do Divino de Bragança Paulista

14h30 - Congada Azul de Bragança Paulista

15h – Duo Jander e Susana "Os canários do Sertão"</p>

                        <div class="progress">
                            <div role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar bg-primary"></div>
                        </div>
                        <div class="page-statistics d-flex justify-content-between">
                            <div class="page-statistics-left"><span>Ingreços Vendidos:</span><strong>130</strong></div>
                            <div class="page-statistics-right"><span>Lote de Vendas Diponivel:</span><strong>73.4%</strong></div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
